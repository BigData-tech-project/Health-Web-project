package com.example.health.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.health.model.UserVo;
import com.example.health.model.UserDao;


@Service
public class UserService {

    @Autowired(required = false)
    private UserDao userDao;

    public UserVo login(String id, String pw) {
        UserVo user = userDao.selectUserById(id);
        if (user != null && user.getPw().equals(pw)) {
            return user;
        }
        return null;
    }

    public int registerUser(UserVo user) {
        return userDao.insertUser(user);
    }
}

SELECT * FROM userinfo;

INSERT INTO userinfo (id, pw, name, gender, age) VALUES 
	('1', '1', 'as', 'Male', 20),
	('2', '2', 'ad', 'Female', 21),
	('3', '3', 'af', 'Male', 22),
	('4', '4', 'ag', 'Female', 23),
	('5', '5', 'ah', 'Male', 24);
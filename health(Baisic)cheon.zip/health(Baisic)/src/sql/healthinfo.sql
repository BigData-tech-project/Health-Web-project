SELECT * FROM healthinfo;

INSERT INTO healthinfo (pressure, sugar, rate, temp, weight) VALUES 
	( 11, 11, 11, 11, 11),
	( 22, 22, 22, 22, 22),
	( 33, 33, 33, 33, 33),
	( 44, 44, 44, 44, 44),
	( 55, 55, 55, 55, 55);
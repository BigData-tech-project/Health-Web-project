SELECT * FROM userinfo;

INSERT INTO userinfo (id, pw, name, gender, age) VALUES ('aaaa','1111', '이건욱' , 'Male', 20),('bbbb', '2222','천예준' , 'Male', 20),('cccc', '3333','유현진' , 'Male', 20),('dddd', '4444','정수현' , 'Female', 20);
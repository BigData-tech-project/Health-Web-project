package com.example.health.model;

public class User {
    private String username;
    private String password;

    // getters and setters
}
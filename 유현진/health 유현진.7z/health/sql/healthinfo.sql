CREATE TABLE healthinfo(
maxpressure INT not null,
minpressure INT not null,
sugar INT not null,
rate INT not null,
temp INT not null,
weight INT not null
);

SELECT * FROM healthinfo;

INSERT INTO healthinfo (maxpressure, minpressure, sugar, rate, temp, weight) VALUES 
   (110, 65, 60, 140, 37, 65),
   (120, 80, 60, 140, 37, 65),
   (114, 80, 70, 140, 37, 65),
   (120, 60, 65, 140, 37, 65);
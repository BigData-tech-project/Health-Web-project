package com.example.health.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.example.health.model.UserVo;

public interface UserMapper {
	
	// = select =
	
	UserVo getUserById(String id);
	
	// = insert = 
	
	void insertUser(UserVo userVo);
	
	// = update = 
	
	
	// = delete = 
	
	
}

package com.example.health.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.health.mapper.UserMapper;
import com.example.health.model.UserVo;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;

    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public UserVo getUserById(String id) {
        return userMapper.getUserById(id);
    }

    @Override
    public void insertUser(UserVo userVo) {
        userMapper.insertUser(userVo);
    }
}

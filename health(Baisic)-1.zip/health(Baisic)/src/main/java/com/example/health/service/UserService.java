package com.example.health.service;

import com.example.health.model.UserVo;

public interface UserService {
    UserVo getUserById(String id);
    void insertUser(UserVo userVo);
}

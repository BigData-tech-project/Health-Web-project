package com.example.health.service;

import com.example.health.model.Notice;
import java.util.List;

public interface NoticeService {
    List<Notice> getAllNotices();
    List<Notice> getLatestNotices(int limit);
}
